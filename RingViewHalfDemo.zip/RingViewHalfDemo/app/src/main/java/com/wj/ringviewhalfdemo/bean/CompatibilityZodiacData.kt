package com.example.mycircleview

data class CompatibilityZodiacData(

        var zodiacImgId: Int,
        var zodiacName: String,
        var zodiacDate: String
)