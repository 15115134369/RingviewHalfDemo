package com.wj.ringviewhalfdemo.weiget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.wj.ringviewhalfdemo.R;
import com.wj.ringviewhalfdemo.util.DensityUtil;
import com.wj.ringviewhalfdemo.util.ScreenUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wjj on 2017/8/9.
 * 1376881525@qq.com
 */

public class RingViewHalf extends ViewGroup {

    private float[] left_select_roation = {-225.0f,-256.0f,-285.0f,-316.0f,-345.0f,-15.0f, -46.0f,-73.0f,-104.0f,-136.0f,-165.0f,-195.0f};
    private float[] right_select_roation = {-43.0f,-74.0f,-105.0f,-135.0f,-164.0f,-195.0f, -224.0f , -254.0f,-284.0f, -313.0f,16.0f, -13.0f};

    private String TAG = "RingViewHalf";
    /**
     * 上一次滑动的坐标
     */
    private float mLastX;
    private float mLastY;
    /**
     * 检测按下到抬起时使用的时间
     */
    private long mDownTime;
    /**
     * 自动滚动线程
     */
    private AngleRunnable mAngleRunnable;
    /**
     * 检测按下到抬起时旋转的角度
     */
    private float mTmpAngle;
    /**
     * 每秒最大移动角度
     */
    private int mMax_Speed;
    /**
     * 如果移动角度达到该值，则屏蔽点击
     */
    private int mMin_Speed;
    /**
     * 圆的直径
     */
    private int mRadius;
    /**
     * 判断是否正在自动滚动
     */
    private boolean isMove;
    /**
     * 布局滚动角度
     */
    private int mStartAngle = 0;
    /**
     * 中间条的宽度
     */
    private int mCircleLineStrokeWidth;
    /**
     * 画圆所在的距形区域
     */
    private final RectF mRectF;
    /**
     * 画笔
     */
    private final Paint mPaint;
    /**
     * 外侧圆宽度
     */
    private int outCirWidth;
    /**
     * 内侧圆宽度
     */
    private int intCirWidth;
    /**
     * 图片内容偏移角度
     */
    private int mImageAngle;
    /**
     * 是否初始化布局
     */
    private boolean isChekc = false;
    /**
     * 外圆颜色
     */
    private int mOutColor;
    /**
     * 内圆颜色
     */
    private int mInColor;
    /**
     * 布局view
     */
    private List<Integer> mImageList = new ArrayList<>();
    /**
     * 是否可点击
     */
    private boolean isCanClick = true;

    /**
     * 图片与环之间的padding
     */
    private int mPadding;
    /**
     * 是否是右边居中的图标为选中图标
     */
    private boolean is_right_select_icon = true;
    /**
     * 是否是右边居中的图标为选中图标
     */
    private Rect select_icon_rect = new Rect();


    //是否能转动
    private boolean mCanScrool;

    public RingViewHalf(Context context) {
        this(context, null, 0);

    }

    public RingViewHalf(Context context, AttributeSet attrs) {
        this(context, attrs, 0);

    }

    public RingViewHalf(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        //获取自定义控件设置的值
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.ringview_half, 0, 0);
        mMax_Speed = array.getInteger(R.styleable.ringview_half_max_speed_rh, 300);
        mMin_Speed = array.getInteger(R.styleable.ringview_half_min_speed_rh, 3);
        outCirWidth = array.getInteger(R.styleable.ringview_half_out_circle_width_rh, 30);
        intCirWidth = array.getInteger(R.styleable.ringview_half_in_circle_width_rh, 20);
        mImageAngle = array.getInteger(R.styleable.ringview_half_image_angle_rh, 0);
        mPadding = array.getInteger(R.styleable.ringview_half_image_padding_rh, 0);
        mOutColor = array.getColor(R.styleable.ringview_half_out_circle_color_rh, 0xffEFF0EB);
        mInColor = array.getColor(R.styleable.ringview_half_in_circle_color_rh, 0xff4daae7);
        mCanScrool = array.getBoolean(R.styleable.ringview_half_can_scroll_rh, true);
        is_right_select_icon = array.getBoolean(R.styleable.ringview_half_is_right_select_icon_rh, true);

        //获取xml定义的资源文件
        TypedArray mList = context.getResources().obtainTypedArray(array.getResourceId(R.styleable.ringview_half_list_rh, 0));
        int len = mList.length();
        if (len > 0) {
            for (int i = 0; i < len; i++)
                mImageList.add(mList.getResourceId(i, 0));
        } else {
            mImageList.add(R.mipmap.ic_launcher);
            mImageList.add(R.mipmap.ic_launcher);
            mImageList.add(R.mipmap.ic_launcher);
        }
        mList.recycle();
        array.recycle();
        mRectF = new RectF();
        mPaint = new Paint();

        int [] location =new int [2];
        getLocationInWindow(location);
        Log.d("locationInWindow",">>>>X=="+location[0]+"y=="+location[1]);
        imagelogo();

        /**
         *  因为默认不走ondraw 所以设置背景透明
         */
//        setBackgroundColor(0x00000000);

    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        if (!isChekc) {
            initView();
            mRadius = getWidth();
            isChekc = true;
        }

    }

    /**
     * 测量
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(widthMeasureSpec, heightMeasureSpec);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int childCount = this.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = this.getChildAt(i);
            this.measureChild(child, widthMeasureSpec, heightMeasureSpec);
            child.getMeasuredWidth();
        }

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = this.getWidth();
        int height = this.getHeight();

        if (width != height) {
            int min = Math.min(width, height);
            width = min;
            height = min;
        }

//        // 设置画笔相关属性
//        mPaint.setAntiAlias(true);
//        //设置画布颜色
//        canvas.drawColor(Color.TRANSPARENT);
//        //设置圆环宽度
//        mPaint.setStrokeWidth(mCircleLineStrokeWidth);
//        //设置为空心圆
//        mPaint.setStyle(Paint.Style.STROKE);


    }


    /**
     * 用canvas 画图标
     *
     * @param canvas
     */
    private void drawLogo(Canvas canvas) {
        int width = this.getWidth();
        int height = this.getHeight();
        if (width != height) {
            int min = Math.min(width, height);
            width = min;
            height = min;
        }
        //图标半径
        int mContent = getWidth() / 2 - mCircleLineStrokeWidth / 2;
        //直接画图标
        for (int i = 1; i < mImageList.size(); i++) {
            Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(),
                    mImageList.get(i));
            //获取圆点上 xy坐标 mAngle 为图片圆半径和大圆半径差值
            float x = (float) (width / 2 + mContent * Math.cos((360 / mImageList.size() * (i + 1) + mImageAngle) * Math.PI / 180)) - bitmap.getWidth() / 2;
            float y = (float) (height / 2 + mContent * Math.sin((360 / mImageList.size() * (i + 1) + mImageAngle) * Math.PI / 180)) - bitmap.getHeight() / 2;
            canvas.drawBitmap(bitmap, null, new RectF(x, y, x + bitmap.getWidth(), y + bitmap.getHeight()), new Paint());
            bitmap.recycle();
        }
    }

    /**
     * 排版布局
     */
    private void initView() {
        int width = this.getWidth();
        int height = this.getHeight();
        if (width != height) {
            int min = Math.min(width, height);
            width = min;
            height = min;
        }
        //不同屏幕分辨率下做不同的处理
        float instPadding = 70f;
        if (ScreenUtils.getScreenWidth(getContext())<=720){
            instPadding = 55f;
        }

        //图片摆放的圆弧半径
        mCircleLineStrokeWidth = getChildAt(0).getMeasuredHeight() + DensityUtil.dip2px(getContext(),instPadding) + mPadding;
        //计算图片圆的半径
        final int mContent = width / 2 - mCircleLineStrokeWidth / 2;
        for (int i = 0; i < getChildCount(); i++) {
            View child = this.getChildAt(i);
            //计算每个图片摆放的角度
            int mAnGle = 360 / mImageList.size() * (i + 1) + mImageAngle;
            //获取每个图片摆放的左上角的x和y坐标
            float left = (float) (width / 2 + mContent * Math.cos(mAnGle * Math.PI / 180)) - child.getMeasuredWidth() / 2;
            float top = (float) (height / 2 + mContent * Math.sin(mAnGle * Math.PI / 180)) - child.getMeasuredHeight() / 2;
            /**
             * 一四象限
             */
            if (getQuadrantByAngle(mAnGle) == 1 || getQuadrantByAngle(mAnGle) == 4) {
//                child.setRotation(mAnGle - 270);
                /**
                 * 二三象限
                 */
            } else {
//                child.setRotation(mAnGle + 90);
            }

            child.layout((int) left, (int) top, (int) left + child.getMeasuredWidth(), (int) top + child.getMeasuredHeight());
        }

    }


    /**
     * 添加子控件
     */
    private void imagelogo() {
        for (int i = 1; i < mImageList.size() + 1; i++) {
            //新建imageview
            final ImageView mImageView = new ImageView(getContext());
            mImageView.setImageResource(mImageList.get(i - 1));
            LayoutParams layoutParams = null;

            mImageView.setScaleType(ImageView.ScaleType.FIT_XY);
            if (is_right_select_icon){
                //右侧icon为选中状态
                if (i==mImageList.size()){
                    mImageView.setAlpha(1f);
                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }else {
                    mImageView.setAlpha(0.5f);
                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }
            }else {
                // 左侧icon为选中状态
                if (i==5){
                    mImageView.setAlpha(1f);
                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }else {
                    mImageView.setAlpha(0.5f);
                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }
            }

            mImageView.setLayoutParams(layoutParams);
            final int finalI = i;
            //添加点击事件
            mImageView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isCanClick) {
//                        Toast.makeText(getContext(),finalI + "   ---", Toast.LENGTH_SHORT).show();
                        if (mOnLogoItemClick != null)
                            mOnLogoItemClick.onItemClick(view, finalI - 1);
                    }

                }
            });
            //添加view
            addView(mImageView);
        }
        //添加view点击事件
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isCanClick) {
                }
            }
        });

    }

    /**
     * 触摸监听
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (mCanScrool) {
            float x = event.getX();
            float y = event.getY();


            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:

                    mLastX = x;
                    mLastY = y;
                    mDownTime = System.currentTimeMillis();
                    mTmpAngle = 0;

                    // 如果当前已经在快速滚动
                    if (isMove) {
                        // 移除快速滚动的回调
                        removeCallbacks(mAngleRunnable);
                        isMove = false;
                        return true;
                    }

                    break;
                case MotionEvent.ACTION_MOVE:
                    /**
                     * 获得开始的角度
                     */
                    float start = getAngle(mLastX, mLastY);
                    /**
                     * 获得当前的角度
                     */
                    float end = getAngle(x, y);
                    Log.e("TAG", "start = " + start + " , end =" + end);
                    // 一四象限
                    if (getQuadrant(x, y) == 1 || getQuadrant(x, y) == 4) {
                        mStartAngle += end - start;
                        mTmpAngle += end - start;
                        //二三象限
                    } else {
                        mStartAngle += start - end;
                        mTmpAngle += start - end;
                    }
                    // 重新布局
                    getCheck();

                    break;
                case MotionEvent.ACTION_UP:
                    // 获取每秒移动的角度
                    float anglePerSecond = mTmpAngle * 1000
                            / (System.currentTimeMillis() - mDownTime);
                    // 如果达到最大速度
                    if (Math.abs(anglePerSecond) > mMax_Speed && !isMove) {
                        // 惯性滚动
                        post(mAngleRunnable = new AngleRunnable(anglePerSecond));
                        return true;
                    }

                    // 如果当前旋转角度超过minSpeed屏蔽点击
                    if (Math.abs(mTmpAngle) > mMin_Speed) {
                        return true;
                    }

                    break;
            }
        }
        return super.dispatchTouchEvent(event);
    }

    /**
     * 获取移动的角度
     */
    private float getAngle(float xTouch, float yTouch) {
        double x = xTouch - (mRadius / 2d);
        double y = yTouch - (mRadius / 2d);
        return (float) (Math.asin(y / Math.hypot(x, y)) * 180 / Math.PI);
    }

    /**
     * 根据当前位置计算象限
     */
    private int getQuadrant(float x, float y) {
        int tmpX = (int) (x - mRadius / 2);
        int tmpY = (int) (y - mRadius / 2);
        if (tmpX >= 0) {
            return tmpY >= 0 ? 4 : 1;
        } else {
            return tmpY >= 0 ? 3 : 2;
        }

    }



    //获取选中icon位置的矩形范围
    public void getSelectIconReft() {

        int [] location = new int [2];
        getLocationOnScreen(location);
        //计算出右侧选中时图标的位置
        if (is_right_select_icon){
//            select_icon_rect.left = location[0]+getWidth()-mCircleLineStrokeWidth/2-getChildAt(0).getWidth()/2;
//            select_icon_rect.top =(location[1]+getHeight()/2)-getChildAt(0).getHeight()/2;
//            select_icon_rect.right = location[0]+getWidth()-mCircleLineStrokeWidth/2+getChildAt(0).getWidth()/2;
//            select_icon_rect.bottom = (location[1]+getHeight()/2)+getChildAt(0).getHeight()/2;
            //选中的icon动态设置宽高为60，没选中宽高55，这里60/2为选中按钮的宽度或者高度的一半，即中心点
            select_icon_rect.left = location[0]+getWidth()-mCircleLineStrokeWidth/2-DensityUtil.dip2px(getContext(),40f)/2;
            select_icon_rect.top =(location[1]+getHeight()/2)-DensityUtil.dip2px(getContext(),40f)/2;
            select_icon_rect.right = location[0]+getWidth()-mCircleLineStrokeWidth/2+DensityUtil.dip2px(getContext(),40f)/2;
            select_icon_rect.bottom = (location[1]+getHeight()/2)+DensityUtil.dip2px(getContext(),40f)/2;

            Log.d("onFocusChanged","右侧选中-----mCircleLineStrokeWidth=="+mCircleLineStrokeWidth+"---left=="+select_icon_rect.left+"---top=="+select_icon_rect.top+"---right=="+select_icon_rect.right+"---bottom=="+select_icon_rect.bottom);
        }else {
            //计算出左侧选中时图标的位置
//            select_icon_rect.left = location[0]+mCircleLineStrokeWidth/2-getChildAt(0).getWidth()/2;
//            select_icon_rect.top = (location[1]+getHeight()/2)-getChildAt(0).getHeight()/2;
//            select_icon_rect.right = location[0]+mCircleLineStrokeWidth/2+getChildAt(0).getWidth()/2;
//            select_icon_rect.bottom =  (location[1]+getHeight()/2)+getChildAt(0).getHeight()/2;
            //选中的icon动态设置宽高为60，没选中宽高55，这里60/2为选中按钮的宽度或者高度的一半，即中心点
            select_icon_rect.left = location[0]+mCircleLineStrokeWidth/2-DensityUtil.dip2px(getContext(),40f)/2;
            select_icon_rect.top = (location[1]+getHeight()/2)-DensityUtil.dip2px(getContext(),40f)/2;
            select_icon_rect.right = location[0]+mCircleLineStrokeWidth/2+DensityUtil.dip2px(getContext(),40f)/2;
            select_icon_rect.bottom =  (location[1]+getHeight()/2)+DensityUtil.dip2px(getContext(),40f)/2;
            Log.d("onFocusChanged","左侧选中-----mCircleLineStrokeWidth=="+mCircleLineStrokeWidth+"---left=="+select_icon_rect.left+"---top=="+select_icon_rect.top+"---right=="+select_icon_rect.right+"---bottom=="+select_icon_rect.bottom);
        }

    }


    /**
     * 通过角度判断象限
     */
    private int getQuadrantByAngle(int angle) {
        if (angle <= 90) {
            return 4;
        } else if (angle <= 180) {
            return 3;
        } else if (angle <= 270) {
            return 2;
        } else {
            return 1;
        }
    }

    /**
     * 惯性滚动
     */
    private class AngleRunnable implements Runnable {

        private float angelPerSecond;
        private float angelPerSecond_start;

        public AngleRunnable(float velocity) {
            this.angelPerSecond = velocity;
            this.angelPerSecond_start = velocity;
        }

        public void run() {
            //小于20停止
            if ((int) Math.abs(angelPerSecond) < 20) {
                isMove = false;
                correctIconImgLocation(true);
                return;
            }
            isMove = true;
            // 滚动时候不断修改滚动角度大小
//            mStartAngle += (angelPerSecond / 30);
            mStartAngle += (angelPerSecond / 40);
            //逐渐减小这个值
            angelPerSecond /= 1.0666F;
            postDelayed(this, 30);
            // 重新布局
            getCheck();

//            if ((int) Math.abs(angelPerSecond) < (int) Math.abs(angelPerSecond_start)/4) {
//            if ((int) Math.abs(angelPerSecond) < (int) Math.abs(angelPerSecond_start)/4||(int) Math.abs(angelPerSecond) < 35||(int) Math.abs(angelPerSecond) < 25||(int) Math.abs(angelPerSecond) < 22) {
            if ((int) Math.abs(angelPerSecond) < (int) Math.abs(angelPerSecond_start)/2||(int) Math.abs(angelPerSecond) < 30||(int) Math.abs(angelPerSecond) < 22) {
//                    correctIconImgLocation(true);
                if (checkIconStateStopScroll()){
                    isMove = false;
                    return;
                }else {

                }
            }
        }
    }

    /**
     * 点击事件接口
     */
    public interface OnLogoItemClick {
        void onItemClick(View view, int pos);
    }

    private OnLogoItemClick mOnLogoItemClick;
    private OnIconSelectedListener mOnIconSelectedListener;

    /**
     * 设置点击事件
     * @param mOnLogoItemClick
     */
    public void addOnItemClick(OnLogoItemClick mOnLogoItemClick) {
        this.mOnLogoItemClick = mOnLogoItemClick;
    }

    /**
     * 到选中位置后选中事件接口
     */
    public interface OnIconSelectedListener{
        void onIconSelected(int pos);
    }

    /**
     * 设置点击事件
     * @param mOnIconSelectedListener
     */
    public void addOnIconSelectedListener(OnIconSelectedListener mOnIconSelectedListener) {
        this.mOnIconSelectedListener = mOnIconSelectedListener;
    }

    /**
     * 旋转圆盘
     */
    private void getCheck() {
        mStartAngle %= 360;
//        //测试
//        mStartAngle=mStartAngle+30-mStartAngle%30;
        Log.d(TAG+"---","-------------------------------mStartAngle==="+mStartAngle);
        setRotation(mStartAngle);

//        int j = 11;
        //改变选中的icon的状态
        setSelectedIcon();
        //停止滚动后根据选中矩形区域与上下两个icon所在imageview在屏幕中的坐标的差距比较，纠正图标位置
        correctIconImgLocation(false);
    }

    /**
     * 旋转圆盘
     */
    private void getCheck2( float angle) {
        //判断当前的角度和想要实现的角度的差距，然后用线程实现缓慢过度的滑动效果
        setRotation(angle);
    }

    private boolean checkIconStateStopScroll(){
        boolean isStopScroll = false;
        for (int j =0;j<getChildCount();j++){
            LayoutParams layoutParams = null;
            int [] location = new int [2];
            getChildAt(j).getLocationOnScreen(location);
            if (is_right_select_icon){
                //右边icon是选中状态的时候
                if (select_icon_rect.left-22<=location[0]&&location[0]<=select_icon_rect.right+22){
                    if (select_icon_rect.top-6<=location[1]&&location[1]<=select_icon_rect.bottom+6){
//                        getChildAt(j).setAlpha(1);
//                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                        //把选中的icon所在list中的position通过接口回传过去
                        if (mOnIconSelectedListener!=null){
                            mOnIconSelectedListener.onIconSelected(j);
                        }
                        isStopScroll = true;
                        return isStopScroll;
                    }else {
//                        getChildAt(j).setAlpha(0.5f);
//                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                    }
                }else {
//                    getChildAt(j).setAlpha(0.5f);
//                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }

            }else {
                //左边icon是选中状态的时候
                if (select_icon_rect.left-22<=location[0]&&location[0]<=select_icon_rect.right+22){
                    if (select_icon_rect.top-6<=location[1]&&location[1]<=select_icon_rect.bottom+6){
//                        getChildAt(j).setAlpha(1);
//                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                        //把选中的icon所在list中的position通过接口回传过去
                        if (mOnIconSelectedListener!=null){
                            mOnIconSelectedListener.onIconSelected(j);

                        }
                        isStopScroll = true;
                        return isStopScroll;
                    }else {
//                        getChildAt(j).setAlpha(0.5f);
//                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                    }
                }else {
//                    getChildAt(j).setAlpha(0.5f);
//                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }
            }
//            getChildAt(j).setLayoutParams(layoutParams);
//            getChildAt(j).invalidate();

            if (isStopScroll){
                return true;
            }

        }
        return isStopScroll;
    }


    //改变选中的icon的状态
    private void setSelectedIcon() {

        if (select_icon_rect.left==0&&select_icon_rect.top==0){
            //fragment中onWindowFocusChanged会出现计算select_icon_rect.left和select_icon_rect.top等于0的情况，
            // 所以做下判断，如果为0则重新调用下计算方法
            getSelectIconReft();
        }

        for (int j =0;j<getChildCount();j++){
            LayoutParams layoutParams = null;
            int [] location = new int [2];
            getChildAt(j).getLocationOnScreen(location);
//            Log.d("getCheck","location[0]=="+location[0]+";select_icon_rect.left=="+select_icon_rect.left+"location[1]=="+location[1]+";select_icon_rect.top=="+select_icon_rect.top);
            if (is_right_select_icon){
                //右边icon是选中状态的时候
                if (select_icon_rect.left-22<=location[0]&&location[0]<=select_icon_rect.right+22){
                    if (select_icon_rect.top-6<=location[1]&&location[1]<=select_icon_rect.bottom+6){
                        getChildAt(j).setAlpha(1);
                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                        //把选中的icon所在list中的position通过接口回传过去
                        if (mOnIconSelectedListener!=null){
                            mOnIconSelectedListener.onIconSelected(j);
                        }
                    }else {
                        getChildAt(j).setAlpha(0.5f);
                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                    }
                }else {
                    getChildAt(j).setAlpha(0.5f);
                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }

            }else {
                //左边icon是选中状态的时候
                if (select_icon_rect.left-22<=location[0]&&location[0]<=select_icon_rect.right+22){
                    if (select_icon_rect.top-6<=location[1]&&location[1]<=select_icon_rect.bottom+6){
                        getChildAt(j).setAlpha(1);
                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                        //把选中的icon所在list中的position通过接口回传过去
                        if (mOnIconSelectedListener!=null){
                            mOnIconSelectedListener.onIconSelected(j);

                        }
                    }else {
                        getChildAt(j).setAlpha(0.5f);
                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                    }
                }else {
                    getChildAt(j).setAlpha(0.5f);
                    layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
                }
            }
            getChildAt(j).setLayoutParams(layoutParams);
            getChildAt(j).invalidate();
            Log.d("getChildCount","=="+j+";class=="+getChildAt(j).getClass()+";left=="+getChildAt(j).getLeft()+";top=="+getChildAt(j).getTop()+";right=="+getChildAt(j).getRight()+";bottom=="+getChildAt(j).getBottom()+";getLocationOnScreen:x="+location[0]+"y="+location[1]);
        }
    }

    //把离选中区域矩形最近的图标位置重新布局位置到选中标准位置
    private void correctIconImgLocation(boolean isLastScroll) {
        //判断是否停止转动后
//        if (!isMove){
            if (select_icon_rect.left==0&&select_icon_rect.top==0){
                //fragment中onWindowFocusChanged会出现计算select_icon_rect.left和select_icon_rect.top等于0的情况，
                // 所以做下判断，如果为0则重新调用下计算方法
                getSelectIconReft();
            }
            //获取到距离选中位置最近的icon的下标
                int nearIndex = getNearstIconIndex();
            for (int j =0;j<getChildCount();j++){
                LayoutParams layoutParams = null;
                int [] location = new int [2];
                getChildAt(j).getLocationOnScreen(location);
                    //右边icon是选中状态的时候
//                    if (select_icon_rect.left-52<=location[0]&&location[0]<=select_icon_rect.right+52) {
                        if (j == nearIndex) {
                            Log.d("correctIconImgLocation", "NearstIndex==" + j + ";x" + location[0] + ";rectX==" + select_icon_rect.left + "Y==" + location[1] + ";rectY==" + select_icon_rect.top);
                            getChildAt(j).setAlpha(1);
                            Log.d("ksksks","当前index=="+j+";currentRowstion=="+getRotation());
                            layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(), 40f), DensityUtil.dip2px(getContext(), 40f));
                            //把选中的icon所在list中的position通过接口回传过去
                            if (mOnIconSelectedListener != null) {
                                mOnIconSelectedListener.onIconSelected(j);
                            }
                        } else {
                            getChildAt(j).setAlpha(0.5f);
                            layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(), 40f), DensityUtil.dip2px(getContext(), 40f));
                        }
//                    }else {
//                        getChildAt(j).setAlpha(0.5f);
//                        layoutParams = new LayoutParams(DensityUtil.dip2px(getContext(),40f), DensityUtil.dip2px(getContext(),40f));
//                    }


                getChildAt(j).setLayoutParams(layoutParams);
                getChildAt(j).invalidate();

                if (isLastScroll){
                    if (is_right_select_icon){
                        getCheck2(right_select_roation[nearIndex]);
                    }else {
                        getCheck2(left_select_roation[nearIndex]);
                    }
                }
            }


//        }
    }

    int[] sortIcon = new int[12];
    List<Integer> sortListX = new ArrayList<>();
    List<Integer> sortListY = new ArrayList<>();
    //冒泡排序算出离选中区域距离最近的icon所在list中的下标index
    private int getNearstIconIndex(){
        int nearestIndex = 0;
        sortListX.clear();
        sortListY.clear();
        //选中矩阵中心y坐标
        int setlectReftY = select_icon_rect.bottom - (select_icon_rect.bottom - select_icon_rect.top) / 2;

        //把当前所有icon中心在屏幕的y坐标与选中矩阵中心y坐标的差值存到一个数组里面
        for (int n=0;n<getChildCount();n++){
            int [] location = new int [2];
            getChildAt(n).getLocationOnScreen(location);
            int iconY = location[1];
            //存起来该下标的icon中心在屏幕的y坐标与选中矩阵中心y坐标的差值
            sortIcon[n] = Math.abs(setlectReftY - iconY);
            sortListY.add(n, Math.abs(setlectReftY - iconY));
            sortListX.add(n,location[0]);
        }
        Log.d(TAG,"sortListY=="+sortListY);
        Log.d(TAG,"sortListX=="+sortListX);

        boolean flag = true;
        while (flag){
            flag = false;
            int temp = 0;
            for (int i = 0;i<sortIcon.length-1;i++){
                for (int j =0;j<sortIcon.length-1-i;j++){
                    if (sortIcon[j+1]<sortIcon[j]){
                        temp = sortIcon[j];
                        sortIcon[j] = sortIcon[j+1];
                        sortIcon[j+1] = temp;
                        flag = true;
                    }
                }
                //优化判断
                if(!flag){  // 若没有交换则排序完成，直接跳出
                    break;
                }
            }
        }

//        Log.d(TAG,"sortListY=="+sortListY);
//        Log.d(TAG,"index=="+sortListY.indexOf(sortIcon[0]));

        //右边icon是选中状态的时候
        boolean isOk = false ;
        for (int l = 0;l<getChildCount();l++){

            int cuX = sortListY.indexOf(sortIcon[l]);
            int avalue ;
            if (is_right_select_icon){
                avalue = 35;
            }else {
                avalue = 30;
            }
            Log.d(TAG,"cuX=="+cuX);
            if (select_icon_rect.left-avalue<=sortListX.get(cuX)&&sortListX.get(cuX)<=select_icon_rect.right+avalue){
                Log.d(TAG,"cuX=="+cuX+"条件成立");
                isOk = true;
            }else {
                Log.d(TAG,"cuX=="+cuX+"条件不成立");
                isOk = false;
            }
            //如果找到了符合条件的最近icon，就跳出循环
            if (isOk){
                nearestIndex = cuX;
                break;
            }
        }

        Log.d(TAG,"index=="+nearestIndex);
        return nearestIndex;

    }

    /**
     * 设置是否可点击
     */
    public void setCanClick(boolean canClick) {
        isCanClick = canClick;
    }


}