package com.wj.ringviewhalfdemo

import android.annotation.SuppressLint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import android.widget.TextView
import com.example.mycircleview.CompatibilityZodiacData
import com.wj.ringviewhalfdemo.util.DensityUtil
import com.wj.ringviewhalfdemo.weiget.RingViewHalf
import com.wj.ringviewhalfdemo.util.ScreenUtils

class MainActivity : AppCompatActivity() {

    private var leftDrawId = R.mipmap.ic_launcher    //左边选中资源id
    private var rightDrawId = R.mipmap.ic_launcher    //右边选中资源id
    private var leftZodiacName = "ddd"    //左边选中名称
    private var rightZodiacName = "fff"   //右边选中名称
    private var zodiacLists = mutableListOf<CompatibilityZodiacData>()

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //不同屏幕分辨率下半圆形选择器的左间距和右间距不能一样，需分开处理才能适配好
        var scall = 0.68
        if (ScreenUtils.getScreenWidth(this)<=800){
//            scall = 0.58
        }

        var ring_left_outside_rl  = findViewById<View>(R.id.ring_left_outside_rl)
        var lp: RelativeLayout.LayoutParams = ring_left_outside_rl.layoutParams as RelativeLayout.LayoutParams
        lp.leftMargin = -(DensityUtil.dip2px(this,350f)*scall).toInt()
        ring_left_outside_rl.layoutParams = lp
        ring_left_outside_rl.invalidate()

        var ring_right_outside_rl  = findViewById<View>(R.id.ring_right_outside_rl)
        var lp2: RelativeLayout.LayoutParams = ring_right_outside_rl.layoutParams as RelativeLayout.LayoutParams
        lp2.rightMargin = -(DensityUtil.dip2px(this,350f)*scall).toInt()
        ring_right_outside_rl.layoutParams = lp2
        ring_right_outside_rl.invalidate()
//        view.ringView_half_right.getSelectIconReft()
        Log.d("MainActivity3","屏幕分辨率：W=="+ScreenUtils.getScreenWidth(this)+";H=="+ScreenUtils.getScreenHeight(this))



        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "111", "3/21 - 4/19"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "222", "4/20 - 5/20"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "333", "5/21 - 6/20"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "444", "6/21 - 7/22"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "555", "7/23 - 8/22"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "666", "8/23 - 9/22"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "777", "9/23 - 10/22"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "888", "10/23 - 11/21"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "999", "11/22 - 12/21"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "sss", "12/22 - 1/19"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "ddd", "1/20 - 2/18"))
        zodiacLists.add(CompatibilityZodiacData(R.mipmap.ic_launcher, "ppp", "2/19 - 3/20"))

        (findViewById<View>(R.id.ringView_half_left) as RingViewHalf).addOnIconSelectedListener { position ->
            Log.d("KKKKKKK", "right.>>>position=="+position)
            rightDrawId = zodiacLists[position].zodiacImgId
            leftZodiacName = zodiacLists[position].zodiacName

            (findViewById<View>(R.id.tv_left) as TextView).text = leftZodiacName
        }
        (findViewById<View>(R.id.ringView_half_right) as RingViewHalf).addOnIconSelectedListener { position ->
            Log.d("KKKKKKK", "right.>>>position=="+position)
            rightDrawId = zodiacLists[position].zodiacImgId
            rightZodiacName = zodiacLists[position].zodiacName
            (findViewById<View>(R.id.tv_right) as TextView).text = rightZodiacName
        }
    }



}
