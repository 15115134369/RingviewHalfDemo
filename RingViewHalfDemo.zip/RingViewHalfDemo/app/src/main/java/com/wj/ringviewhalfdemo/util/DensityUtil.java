package com.wj.ringviewhalfdemo.util;

import android.content.Context;

/**
 * Created by wjj on 2018/5/29.
 */

public class DensityUtil {



    /**
     * @Description dip，dp转化成px 用来处理不同分辨率的屏幕
     */
    public static int dip2px(Context context, Float dpValue) {
        Float scale = context.getResources().getDisplayMetrics().density;
            return (int)(dpValue * scale + 0.5f);
        }


}
